import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { TRAINING_PILLARS } from '../data/gymData';

interface FitnessExperienceProps {
  onSelectPillar: (pillarTitle: string) => void;
}

export const FitnessExperience: React.FC<FitnessExperienceProps> = ({ onSelectPillar }) => {
  return (
    <section id="experience" className="py-24 lg:py-32 bg-[#F5F4EE] border-t border-[#E8E5DC]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 lg:mb-20">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="w-5 h-[1px] bg-[#B8976C]"></span>
              <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
                FITNESS EXPERIENCE
              </span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight">
              TRAIN YOUR WAY.
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm text-[#737373] tracking-wider max-w-sm">
            Focus on what matters to your personal routine with high standards of space and modern gym design.
          </p>
        </div>

        {/* Four Premium Visual Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {TRAINING_PILLARS.map((pillar, index) => (
            <motion.div
              key={pillar.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              id={`experience-card-${pillar.id}`}
              onClick={() => onSelectPillar(pillar.title)}
              className="group cursor-pointer bg-[#FAF9F5] border border-[#E8E5DC] overflow-hidden flex flex-col transition-all duration-300 hover:shadow-[0_12px_30px_rgba(0,0,0,0.06)] hover:border-[#B8976C]/50"
            >
              {/* Image Frame */}
              <div className="relative overflow-hidden aspect-[4/5] bg-[#E8E5DC]">
                <img
                  src={pillar.image}
                  alt={`${pillar.title} at GYMIT DHA Phase 6`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-[#141414]/15 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                {/* Subtle Pillar Index Badge */}
                <div className="absolute top-4 left-4 bg-[#FAF9F5]/95 backdrop-blur-sm px-2.5 py-1 text-[9px] font-bold tracking-[0.2em] text-[#525252] uppercase border border-[#E8E5DC]">
                  0{index + 1}
                </div>

                {/* Arrow Icon in Top Right */}
                <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#FAF9F5]/90 flex items-center justify-center text-[#141414] group-hover:bg-[#141414] group-hover:text-[#FAF9F5] transition-colors shadow-sm">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-display text-lg font-bold tracking-[0.1em] text-[#141414] group-hover:text-[#B8976C] transition-colors mb-2.5">
                    {pillar.title}
                  </h3>
                  <p className="text-xs sm:text-[13px] text-[#525252] leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="pt-5 mt-4 border-t border-[#E8E5DC]/80 flex items-center justify-between text-[10px] font-semibold tracking-[0.2em] text-[#737373] uppercase">
                  <span>GYMIT DHA 6</span>
                  <span className="text-[#B8976C] group-hover:translate-x-0.5 transition-transform">INQUIRE</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
