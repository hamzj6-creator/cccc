import React, { useState, useEffect } from 'react';
import { X, Phone, CheckCircle, MessageSquare, ArrowRight, Clock, MapPin } from 'lucide-react';
import { BUSINESS_DATA } from '../data/gymData';

interface JoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialFocus?: string;
}

export const JoinModal: React.FC<JoinModalProps> = ({
  isOpen,
  onClose,
  initialFocus = 'Fitness',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [focus, setFocus] = useState(initialFocus);
  const [timing, setTiming] = useState('Evening (Open until 1 AM)');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (initialFocus) {
      setFocus(initialFocus);
    }
  }, [initialFocus]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const resetAndClose = () => {
    setIsSubmitted(false);
    setName('');
    setPhone('');
    onClose();
  };

  const whatsappMessage = encodeURIComponent(
    `Hello GYMIT DHA Phase 6, I would like to inquire about joining the gym at Sector H, DHA Phase 6, Lahore.`
  );
  const whatsappUrl = `https://wa.me/923024964888?text=${whatsappMessage}`;

  return (
    <div
      id="join-gymit-modal"
      className="fixed inset-0 z-50 bg-[#141414]/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={resetAndClose}
    >
      <div
        className="relative bg-[#FAF9F5] border border-[#E8E5DC] w-full max-w-lg p-6 sm:p-10 shadow-2xl my-8 text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-join-modal-btn"
          onClick={resetAndClose}
          className="absolute top-5 right-5 p-2 text-[#737373] hover:text-[#141414] transition-colors focus:outline-none"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          <div className="text-center py-6">
            <div className="w-14 h-14 mx-auto mb-5 rounded-full bg-[#B8976C]/20 flex items-center justify-center text-[#B8976C]">
              <CheckCircle className="w-8 h-8" />
            </div>

            <span className="text-[10px] tracking-[0.26em] uppercase text-[#B8976C] font-semibold block mb-2">
              INQUIRY RECEIVED
            </span>

            <h3 className="font-display text-2xl font-bold text-[#141414] mb-3">
              WELCOME TO GYMIT
            </h3>

            <p className="text-sm text-[#525252] leading-relaxed mb-6 max-w-sm mx-auto">
              Thank you, <span className="font-semibold text-[#141414]">{name || 'Member'}</span>. Your inquiry for GYMIT DHA Phase 6 has been registered. You can also call or walk in directly anytime.
            </p>

            <div className="bg-white p-4 border border-[#E8E5DC] text-left text-xs space-y-2 mb-6">
              <div className="flex items-center space-x-2 text-[#404040]">
                <MapPin className="w-4 h-4 text-[#B8976C] shrink-0" />
                <span>H, 78, MB, Sector H, DHA Phase 6, Lahore</span>
              </div>
              <div className="flex items-center space-x-2 text-[#404040]">
                <Clock className="w-4 h-4 text-[#B8976C] shrink-0" />
                <span>Open until 1 AM</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={`tel:${BUSINESS_DATA.phoneClean}`}
                className="flex-1 py-3 px-4 bg-[#141414] text-[#FAF9F5] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#B8976C] hover:text-[#141414] transition-colors text-center inline-flex items-center justify-center space-x-2"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Directly</span>
              </a>
              <button
                onClick={resetAndClose}
                className="flex-1 py-3 px-4 border border-[#141414] text-[#141414] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#FAF9F5] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="mb-6">
              <span className="text-[10px] tracking-[0.28em] uppercase text-[#B8976C] font-semibold block mb-1.5">
                START YOUR ROUTINE
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#141414]">
                JOIN GYMIT DHA PHASE 6
              </h3>
              <p className="text-xs sm:text-sm text-[#525252] mt-2 leading-relaxed">
                Connect directly with the club in DHA Phase 6, Lahore to get started or request a callback.
              </p>
            </div>

            {/* Quick Action Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 pb-6 border-b border-[#E8E5DC]">
              <a
                href={`tel:${BUSINESS_DATA.phoneClean}`}
                id="modal-quick-call-btn"
                className="flex items-center space-x-3 p-3 bg-white border border-[#E8E5DC] hover:border-[#B8976C] transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-[#B8976C]/15 flex items-center justify-center text-[#B8976C] shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] tracking-wider uppercase text-[#737373] block">Instant Call</span>
                  <span className="text-xs font-bold text-[#141414]">{BUSINESS_DATA.phone}</span>
                </div>
              </a>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="modal-quick-whatsapp-btn"
                className="flex items-center space-x-3 p-3 bg-white border border-[#E8E5DC] hover:border-[#B8976C] transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-700 shrink-0">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] tracking-wider uppercase text-[#737373] block">Direct Message</span>
                  <span className="text-xs font-bold text-[#141414]">WhatsApp Chat</span>
                </div>
              </a>
            </div>

            {/* Inquiry Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold tracking-[0.16em] uppercase text-[#404040] mb-1.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your full name"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#E8E5DC] focus:border-[#141414] focus:outline-none text-sm text-[#141414]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold tracking-[0.16em] uppercase text-[#404040] mb-1.5">
                  Contact Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+92 3XX XXXXXXX"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#E8E5DC] focus:border-[#141414] focus:outline-none text-sm text-[#141414]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold tracking-[0.16em] uppercase text-[#404040] mb-1.5">
                    Primary Interest
                  </label>
                  <select
                    value={focus}
                    onChange={(e) => setFocus(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#E8E5DC] focus:border-[#141414] focus:outline-none text-sm text-[#141414]"
                  >
                    <option value="Strength">Strength</option>
                    <option value="Fitness">Fitness</option>
                    <option value="Muscle Building">Muscle Building</option>
                    <option value="Weight Management">Weight Management</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold tracking-[0.16em] uppercase text-[#404040] mb-1.5">
                    Timing
                  </label>
                  <select
                    value={timing}
                    onChange={(e) => setTiming(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#E8E5DC] focus:border-[#141414] focus:outline-none text-sm text-[#141414]"
                  >
                    <option value="Morning">Morning</option>
                    <option value="Afternoon">Afternoon</option>
                    <option value="Evening (Open until 1 AM)">Evening (Open until 1 AM)</option>
                    <option value="Late Night">Late Night (Until 1 AM)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  id="submit-inquiry-btn"
                  className="w-full py-3.5 px-6 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] text-xs font-semibold tracking-[0.24em] uppercase transition-all duration-300 flex items-center justify-center space-x-2 border border-[#141414] hover:border-[#B8976C]"
                >
                  <span>SUBMIT INQUIRY</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="text-center pt-2">
                <span className="text-[10px] tracking-widest text-[#737373] uppercase">
                  Open late until 1 AM · H, 78, MB, Sector H, DHA Phase 6, Lahore
                </span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
