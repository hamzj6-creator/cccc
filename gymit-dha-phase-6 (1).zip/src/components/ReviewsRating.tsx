import React from 'react';
import { motion } from 'motion/react';
import { Star, ExternalLink, ShieldCheck } from 'lucide-react';
import { BUSINESS_DATA } from '../data/gymData';

export const ReviewsRating: React.FC = () => {
  return (
    <section id="reviews" className="py-24 lg:py-32 bg-[#FAF9F5] border-t border-[#E8E5DC]">
      <div className="max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 text-center">
        
        {/* Editorial Subtitle */}
        <div className="inline-flex items-center space-x-2 mb-6 text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
          <ShieldCheck className="w-3.5 h-3.5 text-[#B8976C]" />
          <span>VERIFIED COMMUNITY FEEDBACK</span>
        </div>

        {/* Headline */}
        <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight mb-14">
          TRUSTED BY THE GYMIT COMMUNITY.
        </h2>

        {/* Large Centerpiece Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="p-10 sm:p-14 lg:p-16 bg-white border border-[#E8E5DC] shadow-[0_8px_30px_rgba(0,0,0,0.03)] max-w-2xl mx-auto"
        >
          {/* Large Rating Number */}
          <div className="font-display text-6xl sm:text-7xl font-bold text-[#141414] tracking-tight mb-3">
            {BUSINESS_DATA.rating}
          </div>

          {/* Stars */}
          <div className="flex items-center justify-center space-x-2 text-[#B8976C] mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 fill-[#B8976C] stroke-[#B8976C]" />
            ))}
          </div>

          {/* Reviews Text */}
          <div className="font-display text-xl sm:text-2xl font-semibold text-[#141414] tracking-wide mb-2">
            {BUSINESS_DATA.reviewsCount} Google Reviews
          </div>

          <p className="text-xs sm:text-sm text-[#737373] tracking-widest uppercase mb-10">
            GYMIT DHA Phase 6 · Sector H · Lahore
          </p>

          {/* Action Button: VIEW GOOGLE REVIEWS */}
          <a
            id="view-google-reviews-btn"
            href={BUSINESS_DATA.googleReviewsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center space-x-2.5 px-8 py-4 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] text-xs font-semibold tracking-[0.24em] uppercase transition-all duration-300 border border-[#141414] hover:border-[#B8976C]"
          >
            <span>VIEW GOOGLE REVIEWS</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </motion.div>

      </div>
    </section>
  );
};
