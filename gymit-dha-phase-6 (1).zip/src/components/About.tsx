import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, Check } from 'lucide-react';
import { IMAGES, BUSINESS_DATA } from '../data/gymData';

export const About: React.FC = () => {
  const handleExplore = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const target = document.querySelector('#experience');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-24 lg:py-32 bg-[#FAF9F5] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Large Gym Image Beside Text */}
          <div className="lg:col-span-6 order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative overflow-hidden aspect-[4/3] sm:aspect-[16/12] border border-[#E8E5DC] bg-white shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
                <img
                  src={IMAGES.about}
                  alt="GYMIT DHA Phase 6 modern fitness interior"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transform hover:scale-[1.03] transition-transform duration-700"
                />
              </div>

              {/* Architectural accent note */}
              <div className="mt-4 flex items-center justify-between text-[11px] tracking-[0.2em] text-[#737373] uppercase px-1">
                <span>SECTOR H · MAIN BOULEVARD</span>
                <span>DHA LAHORE</span>
              </div>
            </motion.div>
          </div>

          {/* Editorial Copy */}
          <div className="lg:col-span-6 order-1 lg:order-2 flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
            >
              {/* Small label */}
              <div className="flex items-center space-x-3 mb-6">
                <span className="w-5 h-[1px] bg-[#B8976C]"></span>
                <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
                  THE GYMIT EXPERIENCE
                </span>
              </div>

              {/* Headline */}
              <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight leading-[1.12] mb-8">
                MORE THAN A<br />
                <span className="font-serif-luxury font-normal italic text-[#B8976C]">WORKOUT.</span>
              </h2>

              {/* Description */}
              <p className="text-[#525252] text-base sm:text-lg leading-[1.75] mb-8">
                GYMIT DHA Phase 6 is a fitness center in Lahore for people who want a modern place to train, stay active and work toward their fitness goals.
              </p>

              {/* Distinctive Verified highlights */}
              <div className="space-y-3.5 mb-10 text-sm text-[#404040]">
                <div className="flex items-center space-x-3">
                  <div className="w-5 h-5 rounded-full bg-[#B8976C]/15 flex items-center justify-center text-[#B8976C]">
                    <Check className="w-3 h-3" />
                  </div>
                  <span className="font-medium">Curated light, spacious and clean fitness environment</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-5 h-5 rounded-full bg-[#B8976C]/15 flex items-center justify-center text-[#B8976C]">
                    <Check className="w-3 h-3" />
                  </div>
                  <span className="font-medium">Prime DHA Phase 6 Sector H accessibility in Lahore</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-5 h-5 rounded-full bg-[#B8976C]/15 flex items-center justify-center text-[#B8976C]">
                    <Check className="w-3 h-3" />
                  </div>
                  <span className="font-medium">Late training convenience — open until 1 AM</span>
                </div>
              </div>

              {/* Small CTA */}
              <div>
                <a
                  href="#experience"
                  id="about-explore-cta"
                  onClick={handleExplore}
                  className="inline-flex items-center space-x-2 text-xs font-semibold tracking-[0.24em] uppercase text-[#141414] hover:text-[#B8976C] border-b border-[#141414] hover:border-[#B8976C] pb-1.5 transition-all group"
                >
                  <span>EXPLORE GYMIT</span>
                  <ArrowDown className="w-3.5 h-3.5 transition-transform group-hover:translate-y-1 text-[#B8976C]" />
                </a>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};
