import React from 'react';
import { motion } from 'motion/react';
import { Star, Phone, ArrowRight } from 'lucide-react';
import { BUSINESS_DATA, IMAGES } from '../data/gymData';

interface HeroProps {
  onOpenJoin: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenJoin }) => {
  return (
    <section
      id="home"
      className="relative min-h-[92vh] lg:min-h-screen pt-28 sm:pt-32 lg:pt-36 pb-16 lg:pb-24 flex items-center bg-[#FAF9F5] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 w-full">
        {/* Asymmetric Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 xl:gap-14 items-center">
          
          {/* Left Column: Editorial Content */}
          <div className="lg:col-span-6 xl:col-span-5 flex flex-col justify-center">
            
            {/* Small Label */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-center space-x-3 mb-6"
            >
              <span className="w-6 h-[1px] bg-[#B8976C]"></span>
              <div className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase leading-relaxed">
                GYMIT DHA PHASE 6 <span className="text-[#A3A3A3] mx-1.5">|</span> LAHORE
              </div>
            </motion.div>

            {/* Main Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-4xl sm:text-5xl xl:text-6xl text-[#141414] font-bold tracking-[-0.02em] leading-[1.06] mb-6"
            >
              ELEVATE<br />
              <span className="font-serif-luxury font-normal italic text-[#B8976C]">YOUR</span> FITNESS.
            </motion.h1>

            {/* Supporting Text */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="text-[#525252] text-base sm:text-lg leading-[1.65] font-normal max-w-xl mb-9"
            >
              A premium fitness environment in DHA Phase 6, Lahore designed to help you train consistently and work toward your goals.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 mb-10"
            >
              <button
                id="hero-primary-cta"
                onClick={onOpenJoin}
                className="inline-flex items-center justify-center space-x-2.5 px-8 py-4 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] text-xs font-semibold tracking-[0.24em] uppercase transition-all duration-300 border border-[#141414] hover:border-[#B8976C] group shadow-[0_4px_20px_rgba(20,20,20,0.08)]"
              >
                <span>JOIN GYMIT</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </button>

              <a
                id="hero-secondary-cta"
                href={`tel:${BUSINESS_DATA.phoneClean}`}
                className="inline-flex items-center justify-center space-x-2 px-7 py-4 bg-transparent text-[#141414] hover:bg-[#FAF9F5] hover:text-[#B8976C] text-xs font-semibold tracking-[0.22em] uppercase transition-all duration-300 border border-[#D5D2C8] hover:border-[#B8976C]"
              >
                <Phone className="w-3.5 h-3.5 text-[#B8976C]" />
                <span>CALL NOW</span>
              </a>
            </motion.div>

            {/* Premium Rating Badge */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="inline-flex items-center space-x-4 pt-6 border-t border-[#E8E5DC] w-full max-w-md"
            >
              <div className="flex items-baseline space-x-1">
                <span className="font-display text-2xl font-bold text-[#141414]">4.8</span>
                <span className="text-xs text-[#737373]">/5</span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center space-x-1 text-[#B8976C]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#B8976C] stroke-[#B8976C]" />
                  ))}
                </div>
                <span className="text-[11px] tracking-wider uppercase font-medium text-[#737373] mt-0.5">
                  356 Google Reviews
                </span>
              </div>

              <div className="h-6 w-[1px] bg-[#E8E5DC] mx-2"></div>

              <div className="text-[11px] tracking-wider uppercase text-[#737373]">
                <span className="font-semibold text-[#141414] block">Open Late</span>
                <span>Until 1 AM</span>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Large High-Quality Gym Photograph with Minimal Light Frame */}
          <div className="lg:col-span-6 xl:col-span-7 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="relative"
            >
              {/* Image Container with elegant subtle borders and no dark heavy overlay */}
              <div className="relative overflow-hidden aspect-[4/3] sm:aspect-[16/11] lg:aspect-[16/11] shadow-[0_12px_40px_rgba(0,0,0,0.06)] border border-[#E8E5DC] bg-[#EFEFEB]">
                <img
                  id="hero-gym-image"
                  src={IMAGES.hero}
                  alt="GYMIT DHA Phase 6 Luxury Fitness Center Interior"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform transition-transform duration-1000 hover:scale-[1.02]"
                />
                
                {/* Subtle, delicate gradient along very bottom edge for text contrast if needed */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#141414]/20 via-transparent to-transparent pointer-events-none"></div>

                {/* Floating Architectural Badge */}
                <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-[#FAF9F5]/95 backdrop-blur-md px-4 py-2.5 border border-[#E8E5DC] shadow-sm">
                  <span className="text-[9px] font-bold tracking-[0.28em] text-[#B8976C] uppercase block">
                    SECTOR H · PHASE 6
                  </span>
                  <span className="text-xs font-semibold tracking-wider text-[#141414]">
                    GYMIT DHA LAHORE
                  </span>
                </div>
              </div>

              {/* Decorative Luxury Outline Accent */}
              <div className="hidden sm:block absolute -bottom-4 -right-4 w-full h-full border border-[#B8976C]/30 -z-10 pointer-events-none"></div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};
