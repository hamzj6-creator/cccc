import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, ArrowUpRight } from 'lucide-react';
import { NAV_LINKS, BUSINESS_DATA } from '../data/gymData';

interface NavbarProps {
  onOpenJoin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenJoin }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF9F5]/95 backdrop-blur-md border-b border-[#E8E5DC] py-3.5 shadow-[0_4px_20px_rgba(0,0,0,0.03)]'
          : 'bg-transparent py-5 lg:py-7'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 flex items-center justify-between">
        {/* Brand Logo */}
        <a
          href="#home"
          id="brand-logo-link"
          className="group flex flex-col items-start focus:outline-none"
        >
          <span className="font-display tracking-[0.22em] text-xl sm:text-2xl font-bold text-[#141414] transition-colors group-hover:text-[#B8976C]">
            GYMIT
          </span>
          <span className="text-[9px] sm:text-[10px] tracking-[0.3em] font-medium text-[#737373] uppercase transition-colors group-hover:text-[#141414]">
            DHA PHASE 6
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8 xl:space-x-10" aria-label="Main Navigation">
          {NAV_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              id={`nav-link-${link.label.toLowerCase()}`}
              onClick={(e) => handleNavClick(e, link.href)}
              className="text-[11px] xl:text-xs font-semibold tracking-[0.2em] text-[#404040] hover:text-[#141414] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-[#B8976C] hover:after:w-full after:transition-all after:duration-300"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right CTA Button & Mobile Trigger */}
        <div className="flex items-center space-x-4">
          <a
            href={`tel:${BUSINESS_DATA.phoneClean}`}
            id="navbar-quick-call"
            className="hidden sm:inline-flex items-center space-x-2 text-[11px] tracking-[0.16em] uppercase font-medium text-[#525252] hover:text-[#141414] px-3 py-2 transition-colors"
            title="Call GYMIT DHA Phase 6"
          >
            <Phone className="w-3.5 h-3.5 text-[#B8976C]" />
            <span className="hidden xl:inline">{BUSINESS_DATA.phone}</span>
            <span className="xl:hidden">CALL</span>
          </a>

          <button
            id="navbar-join-btn"
            onClick={onOpenJoin}
            className="hidden sm:inline-flex items-center justify-center text-[11px] sm:text-xs font-semibold tracking-[0.22em] uppercase px-5 py-2.5 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] transition-all duration-300 border border-[#141414] hover:border-[#B8976C]"
          >
            JOIN GYMIT
          </button>

          {/* Mobile Hamburger Button */}
          <button
            id="mobile-menu-toggle"
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#141414] hover:text-[#B8976C] transition-colors focus:outline-none"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer / Overlay Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer-menu"
          className="lg:hidden bg-[#FAF9F5] border-b border-[#E8E5DC] px-6 py-8 shadow-xl transition-all"
        >
          <div className="flex flex-col space-y-4 mb-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                id={`mobile-nav-link-${link.label.toLowerCase()}`}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-sm font-semibold tracking-[0.22em] text-[#141414] hover:text-[#B8976C] py-2 border-b border-[#E8E5DC]/60 flex items-center justify-between"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-4 h-4 text-[#A3A3A3]" />
              </a>
            ))}
          </div>

          <div className="flex flex-col space-y-3 pt-2">
            <button
              id="mobile-join-gymit-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenJoin();
              }}
              className="w-full text-center text-xs font-semibold tracking-[0.24em] uppercase py-3.5 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] transition-colors"
            >
              JOIN GYMIT
            </button>
            <a
              href={`tel:${BUSINESS_DATA.phoneClean}`}
              id="mobile-call-gymit-btn"
              className="w-full text-center text-xs font-semibold tracking-[0.24em] uppercase py-3.5 border border-[#141414] text-[#141414] hover:border-[#B8976C] hover:text-[#B8976C] transition-colors flex items-center justify-center space-x-2"
            >
              <Phone className="w-3.5 h-3.5 text-[#B8976C]" />
              <span>CALL: {BUSINESS_DATA.phone}</span>
            </a>
          </div>

          <div className="mt-6 pt-4 text-center">
            <p className="text-[11px] tracking-wider text-[#737373]">
              H, 78, MB, Sector H, DHA Phase 6, Lahore
            </p>
            <p className="text-[10px] tracking-widest text-[#A3A3A3] mt-1 uppercase">
              {BUSINESS_DATA.openingInfo}
            </p>
          </div>
        </div>
      )}
    </header>
  );
};
