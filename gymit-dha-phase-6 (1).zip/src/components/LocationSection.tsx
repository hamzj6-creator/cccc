import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Compass, ExternalLink } from 'lucide-react';
import { BUSINESS_DATA } from '../data/gymData';

export const LocationSection: React.FC = () => {
  return (
    <section id="location" className="py-24 lg:py-32 bg-[#FAF9F5] border-t border-[#E8E5DC]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Header */}
        <div className="mb-16 lg:mb-20">
          <div className="flex items-center space-x-3 mb-4">
            <span className="w-5 h-[1px] bg-[#B8976C]"></span>
            <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
              LOCATION & ACCESS
            </span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight">
            VISIT GYMIT
          </h2>
        </div>

        {/* Location Grid: Details on Left, Premium Map Container on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-stretch">
          
          {/* Left Column: Business Location Details */}
          <div className="lg:col-span-5 flex flex-col justify-between p-8 sm:p-10 bg-white border border-[#E8E5DC] shadow-[0_4px_24px_rgba(0,0,0,0.02)]">
            <div>
              <div className="border-b border-[#E8E5DC] pb-6 mb-8">
                <span className="text-[10px] tracking-[0.24em] uppercase text-[#B8976C] font-semibold block mb-2">
                  FITNESS CENTER · DHA LAHORE
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#141414]">
                  GYMIT DHA Phase 6
                </h3>
              </div>

              {/* Verified Details List */}
              <div className="space-y-6 text-sm text-[#404040]">
                
                {/* Address */}
                <div className="flex items-start space-x-4">
                  <div className="w-9 h-9 shrink-0 border border-[#E8E5DC] bg-[#FAF9F5] flex items-center justify-center text-[#B8976C]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#737373] block mb-1">
                      Address
                    </span>
                    <p className="font-medium text-[#141414] leading-relaxed">
                      {BUSINESS_DATA.addressLine1}<br />
                      {BUSINESS_DATA.addressLine2}<br />
                      {BUSINESS_DATA.addressLine3}
                    </p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start space-x-4">
                  <div className="w-9 h-9 shrink-0 border border-[#E8E5DC] bg-[#FAF9F5] flex items-center justify-center text-[#B8976C]">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#737373] block mb-1">
                      Phone
                    </span>
                    <a
                      href={`tel:${BUSINESS_DATA.phoneClean}`}
                      id="location-phone-link"
                      className="font-semibold text-[#141414] hover:text-[#B8976C] transition-colors"
                    >
                      {BUSINESS_DATA.phone}
                    </a>
                  </div>
                </div>

                {/* Plus Code */}
                <div className="flex items-start space-x-4">
                  <div className="w-9 h-9 shrink-0 border border-[#E8E5DC] bg-[#FAF9F5] flex items-center justify-center text-[#B8976C]">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#737373] block mb-1">
                      Google Maps Plus Code
                    </span>
                    <p className="font-mono text-xs font-semibold text-[#141414]">
                      {BUSINESS_DATA.plusCode}
                    </p>
                  </div>
                </div>

                {/* Opening Info */}
                <div className="flex items-start space-x-4">
                  <div className="w-9 h-9 shrink-0 border border-[#E8E5DC] bg-[#FAF9F5] flex items-center justify-center text-[#B8976C]">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] tracking-[0.2em] uppercase font-bold text-[#737373] block mb-1">
                      Opening Information
                    </span>
                    <p className="font-semibold text-[#141414] text-sm">
                      {BUSINESS_DATA.openingInfo}
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* GET DIRECTIONS Button */}
            <div className="pt-8 mt-8 border-t border-[#E8E5DC]">
              <a
                id="get-directions-btn"
                href={BUSINESS_DATA.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center space-x-2.5 px-8 py-4 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] text-xs font-semibold tracking-[0.24em] uppercase transition-all duration-300 border border-[#141414] hover:border-[#B8976C]"
              >
                <span>GET DIRECTIONS</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

          {/* Right Column: Premium Dark Map Container with Google Maps Embed */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="relative w-full h-full min-h-[380px] lg:min-h-[480px] bg-[#141414] border border-[#262626] overflow-hidden flex flex-col justify-between shadow-lg">
              
              {/* Top Dark Bar inside map container */}
              <div className="z-10 bg-[#141414]/90 backdrop-blur-md px-6 py-4 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#B8976C] animate-pulse"></div>
                  <span className="text-[11px] font-semibold tracking-[0.22em] text-[#FAF9F5] uppercase">
                    SECTOR H · DHA PHASE 6 · LAHORE
                  </span>
                </div>
                <span className="text-[10px] tracking-widest text-[#A3A3A3] uppercase hidden sm:inline">
                  {BUSINESS_DATA.plusCode}
                </span>
              </div>

              {/* Google Maps Embed iframe */}
              <div className="relative flex-1 w-full h-full min-h-[320px]">
                <iframe
                  id="google-maps-embed"
                  title="GYMIT DHA Phase 6 Map Location"
                  src="https://maps.google.com/maps?q=GYMIT+DHA+Phase+6+Lahore&t=&z=16&ie=UTF8&iwloc=&output=embed"
                  className="w-full h-full border-0 grayscale contrast-125 opacity-85 hover:opacity-100 hover:grayscale-0 transition-all duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                ></iframe>
              </div>

              {/* Bottom Dark Status Bar */}
              <div className="z-10 bg-[#141414] px-6 py-3.5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-[#A3A3A3] space-y-2 sm:space-y-0">
                <span>GYMIT · H, 78, MB, Sector H, DHA Phase 6</span>
                <a
                  href={BUSINESS_DATA.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[11px] tracking-[0.2em] uppercase text-[#B8976C] hover:underline inline-flex items-center space-x-1"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
