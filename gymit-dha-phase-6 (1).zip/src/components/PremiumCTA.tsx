import React from 'react';
import { motion } from 'motion/react';
import { Phone, ArrowRight } from 'lucide-react';
import { BUSINESS_DATA, IMAGES } from '../data/gymData';

interface PremiumCTAProps {
  onOpenJoin: () => void;
}

export const PremiumCTA: React.FC<PremiumCTAProps> = ({ onOpenJoin }) => {
  return (
    <section id="cta-section" className="py-20 sm:py-24 bg-[#FAF9F5] border-t border-[#E8E5DC]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Split Container: Large Gym Image on one side, Ivory Panel on the other */}
        <div className="grid grid-cols-1 lg:grid-cols-12 border border-[#E8E5DC] shadow-[0_12px_40px_rgba(0,0,0,0.04)] overflow-hidden">
          
          {/* Left Side: Large Gym Image */}
          <div className="lg:col-span-6 relative aspect-[4/3] sm:aspect-[16/10] lg:aspect-auto min-h-[340px] lg:min-h-[460px] bg-[#141414]">
            <img
              src={IMAGES.galleryWide}
              alt="GYMIT DHA Phase 6 fitness environment"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-black/20"></div>
            
            {/* Subtle Overlay Badge */}
            <div className="absolute bottom-6 left-6 bg-[#141414]/90 backdrop-blur-md px-4 py-2 border border-white/10 text-white">
              <span className="text-[9px] font-bold tracking-[0.25em] text-[#B8976C] uppercase block">
                DHA PHASE 6
              </span>
              <span className="text-xs font-semibold tracking-wider uppercase">
                SECTOR H · LAHORE
              </span>
            </div>
          </div>

          {/* Right Side: Ivory Panel */}
          <div className="lg:col-span-6 bg-[#FAF9F5] p-8 sm:p-12 lg:p-16 flex flex-col justify-center border-t lg:border-t-0 lg:border-l border-[#E8E5DC]">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center space-x-3 mb-6">
                <span className="w-5 h-[1px] bg-[#B8976C]"></span>
                <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
                  READY TO TRAIN
                </span>
              </div>

              {/* Headline */}
              <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight leading-[1.08] mb-6">
                MAKE YOUR<br />
                <span className="font-serif-luxury font-normal italic text-[#B8976C]">NEXT</span> MOVE.
              </h2>

              {/* Text */}
              <p className="text-sm sm:text-base text-[#525252] leading-relaxed mb-8 max-w-md">
                Start your fitness journey at GYMIT DHA Phase 6.
              </p>

              {/* Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                <button
                  id="cta-join-btn"
                  onClick={onOpenJoin}
                  className="inline-flex items-center justify-center space-x-2.5 px-8 py-4 bg-[#141414] text-[#FAF9F5] hover:bg-[#B8976C] hover:text-[#141414] text-xs font-semibold tracking-[0.24em] uppercase transition-all duration-300 border border-[#141414] hover:border-[#B8976C] group shadow-sm"
                >
                  <span>JOIN GYMIT</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </button>

                <a
                  id="cta-call-btn"
                  href={`tel:${BUSINESS_DATA.phoneClean}`}
                  className="inline-flex items-center justify-center space-x-2 px-7 py-4 bg-transparent text-[#141414] hover:bg-white hover:text-[#B8976C] text-xs font-semibold tracking-[0.22em] uppercase transition-all duration-300 border border-[#D5D2C8] hover:border-[#B8976C]"
                >
                  <Phone className="w-3.5 h-3.5 text-[#B8976C]" />
                  <span>CALL NOW</span>
                </a>
              </div>

              {/* Direct phone display */}
              <div className="mt-8 pt-6 border-t border-[#E8E5DC] text-[11px] tracking-wider text-[#737373] uppercase">
                <span>Direct Inquiries: </span>
                <a href={`tel:${BUSINESS_DATA.phoneClean}`} className="font-semibold text-[#141414] hover:text-[#B8976C] ml-1">
                  {BUSINESS_DATA.phone}
                </a>
              </div>
            </motion.div>
          </div>

        </div>

      </div>
    </section>
  );
};
