import React from 'react';
import { motion } from 'motion/react';
import { Star, Clock, MapPin, Sparkles } from 'lucide-react';
import { WHY_POINTS, BUSINESS_DATA } from '../data/gymData';

export const WhyGymit: React.FC = () => {
  return (
    <section id="training" className="py-24 lg:py-32 bg-[#FAF9F5] border-t border-[#E8E5DC]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Header */}
        <div className="mb-16 lg:mb-20 max-w-2xl">
          <div className="flex items-center space-x-3 mb-4">
            <span className="w-5 h-[1px] bg-[#B8976C]"></span>
            <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
              DISTINCTION
            </span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight">
            WHY GYMIT?
          </h2>
        </div>

        {/* Four Editorial Numbered Points */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {WHY_POINTS.map((point, index) => (
            <motion.div
              key={point.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="p-8 sm:p-10 bg-white border border-[#E8E5DC] flex flex-col justify-between hover:border-[#B8976C]/60 transition-colors shadow-[0_4px_24px_rgba(0,0,0,0.02)]"
            >
              <div>
                <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#E8E5DC]">
                  <span className="font-display text-3xl sm:text-4xl font-bold text-[#B8976C]">
                    {point.number}
                  </span>
                  {index === 0 && <Sparkles className="w-5 h-5 text-[#B8976C]" />}
                  {index === 1 && <MapPin className="w-5 h-5 text-[#B8976C]" />}
                  {index === 2 && <Star className="w-5 h-5 text-[#B8976C] fill-[#B8976C]" />}
                  {index === 3 && <Clock className="w-5 h-5 text-[#B8976C]" />}
                </div>

                <h3 className="font-display text-lg sm:text-xl font-bold tracking-[0.14em] uppercase text-[#141414] mb-3">
                  {point.title}
                </h3>

                <p className="text-sm sm:text-base text-[#525252] leading-relaxed mb-6">
                  {point.detail}
                </p>
              </div>

              {/* Verified pill / highlight badge */}
              {point.subdetail && (
                <div className="pt-4 border-t border-[#E8E5DC]/80 flex items-center justify-between">
                  <span className="inline-flex items-center text-xs font-semibold tracking-wider text-[#141414] bg-[#FAF9F5] px-3 py-1.5 border border-[#E8E5DC]">
                    {point.subdetail}
                  </span>
                  <span className="text-[10px] tracking-[0.2em] uppercase text-[#737373]">
                    VERIFIED
                  </span>
                </div>
              )}
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
