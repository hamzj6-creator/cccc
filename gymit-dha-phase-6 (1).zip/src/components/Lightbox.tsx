import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { GalleryItem } from '../types';

interface LightboxProps {
  items: GalleryItem[];
  currentIndex: number | null;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Lightbox: React.FC<LightboxProps> = ({
  items,
  currentIndex,
  onClose,
  onNext,
  onPrev,
}) => {
  if (currentIndex === null) return null;
  const currentItem = items[currentIndex];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNext();
      if (e.key === 'ArrowLeft') onPrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, onNext, onPrev]);

  return (
    <div
      id="gallery-lightbox-modal"
      className="fixed inset-0 z-50 bg-[#141414]/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 lg:p-10 animate-fade-in"
      onClick={onClose}
    >
      {/* Top Bar */}
      <div
        className="absolute top-4 left-4 right-4 sm:top-6 sm:left-8 sm:right-8 flex items-center justify-between z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col text-[#FAF9F5]">
          <span className="text-[10px] tracking-[0.24em] uppercase text-[#B8976C]">
            GYMIT DHA PHASE 6 · THE SPACE
          </span>
          <span className="text-sm font-semibold tracking-wider">
            {currentItem.title} ({currentIndex + 1}/{items.length})
          </span>
        </div>

        <button
          onClick={onClose}
          id="lightbox-close-btn"
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors focus:outline-none"
          aria-label="Close image viewer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Image Container */}
      <div
        className="relative max-w-6xl max-h-[80vh] w-full flex items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={currentItem.image}
          alt={currentItem.title}
          referrerPolicy="no-referrer"
          className="max-h-[80vh] max-w-full object-contain rounded-none shadow-2xl border border-white/10"
        />

        {/* Previous Button */}
        <button
          id="lightbox-prev-btn"
          onClick={onPrev}
          className="absolute left-2 sm:left-4 p-3 rounded-full bg-black/40 hover:bg-black/80 text-white transition-colors focus:outline-none border border-white/10"
          aria-label="Previous image"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        {/* Next Button */}
        <button
          id="lightbox-next-btn"
          onClick={onNext}
          className="absolute right-2 sm:right-4 p-3 rounded-full bg-black/40 hover:bg-black/80 text-white transition-colors focus:outline-none border border-white/10"
          aria-label="Next image"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Bottom Caption */}
      <div
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center text-xs tracking-widest text-[#A3A3A3] uppercase"
        onClick={(e) => e.stopPropagation()}
      >
        <span>Press ESC to close · Arrows to navigate</span>
      </div>
    </div>
  );
};
