import React from 'react';
import { Star, MapPin } from 'lucide-react';
import { BUSINESS_DATA } from '../data/gymData';

export const TrustProof: React.FC = () => {
  return (
    <section
      id="trust-section"
      className="border-y border-[#E8E5DC] bg-[#FAF9F5] py-10 sm:py-12"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-6 divide-y md:divide-y-0 md:divide-x divide-[#E8E5DC]">
          
          {/* Rating */}
          <div className="flex items-center justify-start md:justify-center space-x-4 pt-2 md:pt-0">
            <div className="font-display text-4xl sm:text-5xl font-bold text-[#141414] tracking-tight">
              {BUSINESS_DATA.rating}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center space-x-1 text-[#B8976C] mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#B8976C] stroke-[#B8976C]" />
                ))}
              </div>
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#737373]">
                Google Rating
              </span>
            </div>
          </div>

          {/* Reviews Count */}
          <div className="flex items-center justify-start md:justify-center space-x-4 pt-6 md:pt-0">
            <div className="font-display text-4xl sm:text-5xl font-bold text-[#141414] tracking-tight">
              {BUSINESS_DATA.reviewsCount}
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#141414]">
                Google Reviews
              </span>
              <span className="text-[11px] text-[#737373] tracking-wider uppercase mt-0.5">
                Verified Community
              </span>
            </div>
          </div>

          {/* Location / Destination */}
          <div className="flex items-center justify-start md:justify-center space-x-4 pt-6 md:pt-0">
            <div className="w-11 h-11 border border-[#E8E5DC] bg-white flex items-center justify-center text-[#B8976C]">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="font-display text-base font-bold tracking-[0.16em] uppercase text-[#141414]">
                DHA PHASE 6
              </span>
              <span className="text-xs font-medium tracking-[0.2em] uppercase text-[#737373] mt-0.5">
                Lahore, Pakistan
              </span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
