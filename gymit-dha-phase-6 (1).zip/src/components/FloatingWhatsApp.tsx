import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { BUSINESS_DATA } from '../data/gymData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  // Phone number +92 03024964888 formatted for WhatsApp wa.me API (country code 92 without leading 0: 923024964888)
  const whatsappNumber = '923024964888';
  const prefilledMessage = encodeURIComponent(
    'Hello GYMIT DHA Phase 6 Lahore, I would like to inquire about membership, personal training, and visiting the gym at Sector H.'
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${prefilledMessage}`;

  return (
    <div
      id="floating-whatsapp-container"
      className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40 flex items-end flex-col space-y-2 select-none pointer-events-auto"
    >
      {/* Optional Editorial Tooltip Banner on Desktop */}
      {showTooltip && (
        <div
          id="whatsapp-tooltip-card"
          className="hidden md:flex items-center space-x-3 bg-white border border-[#E8E5DC] text-[#141414] py-2.5 px-3.5 shadow-xl shadow-black/10 rounded-sm mb-1 max-w-xs animate-in fade-in slide-in-from-bottom-2 duration-300"
        >
          <div className="flex-1 text-left">
            <div className="flex items-center space-x-1.5 mb-0.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#25D366] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#25D366]"></span>
              </span>
              <p className="text-[11px] font-semibold tracking-wider uppercase text-[#737373]">
                {BUSINESS_DATA.openingInfo}
              </p>
            </div>
            <p className="text-xs font-medium text-[#141414] leading-snug">
              Message <span className="font-semibold">GYMIT DHA Phase 6</span> on WhatsApp
            </p>
          </div>
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setShowTooltip(false);
            }}
            id="whatsapp-tooltip-close"
            className="text-[#A3A3A3] hover:text-[#141414] p-1 transition-colors"
            aria-label="Close tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        id="floating-whatsapp-btn"
        aria-label="Message GYMIT DHA Phase 6 Lahore on WhatsApp at +92 302 4964888"
        className="group relative flex items-center bg-[#25D366] hover:bg-[#20BA5A] text-white p-3.5 sm:px-4 sm:py-3.5 rounded-full shadow-lg shadow-[#25D366]/35 hover:shadow-xl hover:shadow-[#25D366]/45 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 focus:outline-none focus:ring-2 focus:ring-[#25D366] focus:ring-offset-2 focus:ring-offset-[#FAF9F5]"
      >
        {/* Pulsing indicator ring */}
        <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-[#141414] border-2 border-white"></span>
        </span>

        <MessageCircle className="w-6 h-6 shrink-0 text-white fill-current transition-transform duration-300 group-hover:scale-110" />

        {/* Text label visible on desktop */}
        <div className="hidden sm:flex flex-col ml-2.5 text-left pr-1">
          <span className="text-[10px] uppercase font-bold tracking-[0.14em] text-white/90 leading-tight">
            WhatsApp
          </span>
          <span className="text-xs font-semibold tracking-wide text-white leading-tight">
            Chat with GYMIT
          </span>
        </div>
      </a>
    </div>
  );
};
