import React from 'react';
import { Phone, MapPin } from 'lucide-react';
import { BUSINESS_DATA, NAV_LINKS } from '../data/gymData';

export const Footer: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="main-footer" className="bg-[#141414] text-[#FAF9F5] pt-20 pb-12 border-t border-[#262626]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16 pb-16 border-b border-[#262626]">
          
          {/* Brand Column */}
          <div className="md:col-span-6 lg:col-span-5">
            <div className="mb-6">
              <span className="font-display tracking-[0.24em] text-2xl sm:text-3xl font-bold text-white block">
                GYMIT
              </span>
              <span className="text-xs tracking-[0.32em] font-semibold text-[#B8976C] uppercase block mt-1">
                DHA PHASE 6 · LAHORE
              </span>
            </div>

            <p className="text-xs text-[#A3A3A3] leading-relaxed max-w-sm mb-6">
              A premium fitness environment in DHA Phase 6, Lahore designed to help you train consistently and work toward your goals.
            </p>

            <div className="space-y-2 text-xs text-[#D4D4D4]">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-[#B8976C] shrink-0 mt-0.5" />
                <span>{BUSINESS_DATA.fullAddress}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-[#B8976C] shrink-0" />
                <a
                  href={`tel:${BUSINESS_DATA.phoneClean}`}
                  className="hover:text-[#B8976C] transition-colors"
                >
                  {BUSINESS_DATA.phone}
                </a>
              </div>
            </div>
          </div>

          {/* Navigation Column */}
          <div className="md:col-span-6 lg:col-span-7 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold tracking-[0.28em] text-[#737373] uppercase block mb-6">
                NAVIGATION
              </span>

              <ul className="grid grid-cols-2 sm:grid-cols-3 gap-y-3.5 gap-x-6">
                {NAV_LINKS.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link.href)}
                      className="text-xs tracking-[0.2em] font-medium text-[#A3A3A3] hover:text-[#FAF9F5] transition-colors uppercase block"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-[#262626]/80 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-[#737373]">
              <span>Opening: {BUSINESS_DATA.openingInfo}</span>
              <span className="mt-2 sm:mt-0 font-mono text-[11px] text-[#A3A3A3]">
                {BUSINESS_DATA.plusCode}
              </span>
            </div>
          </div>

        </div>

        {/* Copyright Line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#737373] tracking-wider">
          <p>© 2026 GYMIT DHA Phase 6. All rights reserved.</p>
          <p className="mt-2 sm:mt-0 text-[11px] text-[#525252]">
            DHA Phase 6, Lahore, Pakistan
          </p>
        </div>

      </div>
    </footer>
  );
};
