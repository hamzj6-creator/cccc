import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Maximize2 } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/gymData';
import { Lightbox } from './Lightbox';

export const Gallery: React.FC = () => {
  const [activeImageIndex, setActiveImageIndex] = useState<number | null>(null);

  const handleOpen = (index: number) => {
    setActiveImageIndex(index);
  };

  const handleClose = () => {
    setActiveImageIndex(null);
  };

  const handleNext = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex + 1) % GALLERY_ITEMS.length);
    }
  };

  const handlePrev = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length);
    }
  };

  return (
    <section id="gallery" className="py-28 lg:py-36 bg-[#FAF9F5] border-t border-[#E8E5DC]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        
        {/* Section Header with generous whitespace */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 lg:mb-24">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="w-5 h-[1px] bg-[#B8976C]"></span>
              <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.28em] text-[#525252] uppercase">
                EDITORIAL GALLERY
              </span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl xl:text-5xl text-[#141414] font-bold tracking-tight">
              THE SPACE
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-xs sm:text-sm text-[#737373] tracking-widest uppercase">
            Curated views of GYMIT DHA Phase 6 · Lahore
          </p>
        </div>

        {/* Magazine-Style Layout:
            - 1 Large Cinematic Image (Item 0)
            - 2 Smaller Images (Items 1 & 2)
            - 1 Wide Image (Item 3)
            - 1 Vertical Image (Item 4)
        */}
        <div className="space-y-8 lg:space-y-12">
          
          {/* Row 1: Large Cinematic Image */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="group relative cursor-pointer overflow-hidden border border-[#E8E5DC] bg-white aspect-[16/9] sm:aspect-[21/9]"
            onClick={() => handleOpen(0)}
          >
            <img
              src={GALLERY_ITEMS[0].image}
              alt={GALLERY_ITEMS[0].title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-[1.02] group-hover:brightness-[1.03]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
            
            <div className="absolute bottom-6 left-6 sm:bottom-8 sm:left-8 flex items-end justify-between right-6 sm:right-8 text-white">
              <div>
                <span className="text-[10px] tracking-[0.25em] text-[#B8976C] uppercase block mb-1">
                  01 · {GALLERY_ITEMS[0].category}
                </span>
                <h3 className="font-display text-lg sm:text-2xl font-bold tracking-wide">
                  {GALLERY_ITEMS[0].title}
                </h3>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white group-hover:bg-[#B8976C] group-hover:text-black transition-colors">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>
          </motion.div>

          {/* Row 2: 1 Vertical Image + 2 Smaller Images in a Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            
            {/* 1 Vertical Image (Item 4) */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="lg:col-span-5 group relative cursor-pointer overflow-hidden border border-[#E8E5DC] bg-white aspect-[3/4] sm:aspect-[4/5] lg:aspect-[3/4]"
              onClick={() => handleOpen(4)}
            >
              <img
                src={GALLERY_ITEMS[4].image}
                alt={GALLERY_ITEMS[4].title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-[1.03] group-hover:brightness-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
              
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between text-white">
                <div>
                  <span className="text-[10px] tracking-[0.25em] text-[#B8976C] uppercase block mb-1">
                    02 · {GALLERY_ITEMS[4].category}
                  </span>
                  <h3 className="font-display text-base sm:text-xl font-bold">
                    {GALLERY_ITEMS[4].title}
                  </h3>
                </div>
                <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white group-hover:bg-[#B8976C] group-hover:text-black transition-colors">
                  <Maximize2 className="w-4 h-4" />
                </div>
              </div>
            </motion.div>

            {/* 2 Smaller Images (Items 1 & 2) stacked or side-by-side */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-8 lg:space-y-0">
              
              {/* Smaller Image 1 (Item 1) */}
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="group relative cursor-pointer overflow-hidden border border-[#E8E5DC] bg-white aspect-[16/9] lg:aspect-[16/8.5]"
                onClick={() => handleOpen(1)}
              >
                <img
                  src={GALLERY_ITEMS[1].image}
                  alt={GALLERY_ITEMS[1].title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-[1.03] group-hover:brightness-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                
                <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between text-white">
                  <div>
                    <span className="text-[10px] tracking-[0.25em] text-[#B8976C] uppercase block mb-1">
                      03 · {GALLERY_ITEMS[1].category}
                    </span>
                    <h3 className="font-display text-base sm:text-lg font-bold">
                      {GALLERY_ITEMS[1].title}
                    </h3>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white group-hover:bg-[#B8976C] group-hover:text-black transition-colors">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>
                </div>
              </motion.div>

              {/* Smaller Image 2 (Item 2) */}
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="group relative cursor-pointer overflow-hidden border border-[#E8E5DC] bg-white aspect-[16/9] lg:aspect-[16/8.5]"
                onClick={() => handleOpen(2)}
              >
                <img
                  src={GALLERY_ITEMS[2].image}
                  alt={GALLERY_ITEMS[2].title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-[1.03] group-hover:brightness-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                
                <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between text-white">
                  <div>
                    <span className="text-[10px] tracking-[0.25em] text-[#B8976C] uppercase block mb-1">
                      04 · {GALLERY_ITEMS[2].category}
                    </span>
                    <h3 className="font-display text-base sm:text-lg font-bold">
                      {GALLERY_ITEMS[2].title}
                    </h3>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white group-hover:bg-[#B8976C] group-hover:text-black transition-colors">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>
                </div>
              </motion.div>

            </div>
          </div>

          {/* Row 3: One Wide Image (Item 3) */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="group relative cursor-pointer overflow-hidden border border-[#E8E5DC] bg-white aspect-[16/8] sm:aspect-[21/8]"
            onClick={() => handleOpen(3)}
          >
            <img
              src={GALLERY_ITEMS[3].image}
              alt={GALLERY_ITEMS[3].title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-[1.02] group-hover:brightness-[1.03]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
            
            <div className="absolute bottom-6 left-6 sm:bottom-8 sm:left-8 right-6 sm:right-8 flex items-end justify-between text-white">
              <div>
                <span className="text-[10px] tracking-[0.25em] text-[#B8976C] uppercase block mb-1">
                  05 · {GALLERY_ITEMS[3].category}
                </span>
                <h3 className="font-display text-lg sm:text-2xl font-bold tracking-wide">
                  {GALLERY_ITEMS[3].title}
                </h3>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white group-hover:bg-[#B8976C] group-hover:text-black transition-colors">
                <Maximize2 className="w-4 h-4" />
              </div>
            </div>
          </motion.div>

        </div>

      </div>

      {/* Lightbox Modal */}
      <Lightbox
        items={GALLERY_ITEMS}
        currentIndex={activeImageIndex}
        onClose={handleClose}
        onNext={handleNext}
        onPrev={handlePrev}
      />
    </section>
  );
};
