import { BusinessInfo, TrainingPillar, WhyPoint, GalleryItem } from '../types';

import heroImg from '../assets/images/gymit_hero_interior_1789379383396.jpg';
import aboutImg from '../assets/images/regenerated_image_1789380190162.png';
import galleryHeroImg from '../assets/images/regenerated_image_1789380193130.png';
import vertGalleryImg from '../assets/images/gymit_gallery_vert_1789379412988.jpg';
import wideGalleryImg from '../assets/images/gymit_space_wide_1789379456540.jpg';

export const BUSINESS_DATA: BusinessInfo = {
  name: "GYMIT",
  subName: "DHA PHASE 6",
  category: "Fitness Center",
  addressLine1: "H, 78, MB, Sector H,",
  addressLine2: "DHA Phase 6,",
  addressLine3: "Lahore, Pakistan",
  fullAddress: "H, 78, MB, Sector H, DHA Phase 6, Lahore, Pakistan",
  phone: "+92 302 4964888",
  phoneClean: "+923024964888",
  rating: 4.8,
  reviewsCount: 356,
  plusCode: "FCGX+V6 Lahore, Pakistan",
  openingInfo: "Open until 1 AM",
  googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=GYMIT+DHA+Phase+6+H+78+MB+Sector+H+Lahore+Pakistan",
  googleReviewsUrl: "https://www.google.com/maps/search/?api=1&query=GYMIT+DHA+Phase+6+Lahore"
};

export const IMAGES = {
  hero: heroImg,
  about: aboutImg,
  galleryMain: galleryHeroImg,
  galleryVert: vertGalleryImg,
  galleryWide: wideGalleryImg,
  strength: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1200&auto=format&fit=crop",
  fitness: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=1200&auto=format&fit=crop",
  muscle: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=1200&auto=format&fit=crop",
  weight: "https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=1200&auto=format&fit=crop",
  trainingFloor: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?q=80&w=1200&auto=format&fit=crop",
  freeWeights: "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?q=80&w=1200&auto=format&fit=crop"
};

export const TRAINING_PILLARS: TrainingPillar[] = [
  {
    id: "strength",
    title: "STRENGTH",
    description: "Build strength through consistent resistance training.",
    image: IMAGES.strength,
    aspect: "aspect-[4/5]"
  },
  {
    id: "fitness",
    title: "FITNESS",
    description: "Improve your fitness and maintain an active lifestyle.",
    image: IMAGES.fitness,
    aspect: "aspect-[4/5]"
  },
  {
    id: "muscle-building",
    title: "MUSCLE BUILDING",
    description: "Work consistently toward your physique goals.",
    image: IMAGES.muscle,
    aspect: "aspect-[4/5]"
  },
  {
    id: "weight-management",
    title: "WEIGHT MANAGEMENT",
    description: "Support your fitness and body-composition goals through regular exercise.",
    image: IMAGES.weight,
    aspect: "aspect-[4/5]"
  }
];

export const WHY_POINTS: WhyPoint[] = [
  {
    number: "01",
    title: "PREMIUM FITNESS ENVIRONMENT",
    detail: "A refined space designed for focused training, consistency, and an elevated club atmosphere.",
  },
  {
    number: "02",
    title: "DHA PHASE 6 LOCATION",
    detail: "Situated centrally at H, 78, MB in Sector H, DHA Phase 6, Lahore for effortless local access.",
  },
  {
    number: "03",
    title: "HIGHLY RATED BY MEMBERS",
    detail: "Backed by a verified 4.8-star Google rating and 356 member reviews across Lahore.",
    subdetail: "4.8 ★★★★★ · 356 Google Reviews"
  },
  {
    number: "04",
    title: "OPEN LATE",
    detail: "Conveniently open until 1 AM to fit modern schedules and late evening training routines.",
    subdetail: "Open until 1 AM"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gal-1",
    title: "Main Training Space",
    category: "Main Floor",
    image: galleryHeroImg,
    aspectRatio: "cinematic"
  },
  {
    id: "gal-2",
    title: "Resistance Studio",
    category: "Equipment",
    image: aboutImg,
    aspectRatio: "standard"
  },
  {
    id: "gal-3",
    title: "Free Weights & Detail",
    category: "Conditioning",
    image: IMAGES.freeWeights,
    aspectRatio: "standard"
  },
  {
    id: "gal-4",
    title: "Architectural Perspective",
    category: "Environment",
    image: wideGalleryImg,
    aspectRatio: "wide"
  },
  {
    id: "gal-5",
    title: "Minimalist Club Atmosphere",
    category: "Space",
    image: vertGalleryImg,
    aspectRatio: "tall"
  }
];

export const NAV_LINKS = [
  { label: "HOME", href: "#home" },
  { label: "ABOUT", href: "#about" },
  { label: "EXPERIENCE", href: "#experience" },
  { label: "TRAINING", href: "#training" },
  { label: "GALLERY", href: "#gallery" },
  { label: "REVIEWS", href: "#reviews" },
  { label: "LOCATION", href: "#location" },
];
