import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustProof } from './components/TrustProof';
import { About } from './components/About';
import { FitnessExperience } from './components/FitnessExperience';
import { WhyGymit } from './components/WhyGymit';
import { Gallery } from './components/Gallery';
import { ReviewsRating } from './components/ReviewsRating';
import { PremiumCTA } from './components/PremiumCTA';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { JoinModal } from './components/JoinModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { BUSINESS_DATA } from './data/gymData';

export default function App() {
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [selectedPillar, setSelectedPillar] = useState('Fitness');

  const handleOpenJoin = (focus: string = 'Fitness') => {
    setSelectedPillar(focus);
    setIsJoinModalOpen(true);
  };

  const handleCloseJoin = () => {
    setIsJoinModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#141414] font-sans antialiased selection:bg-[#B8976C]/20 selection:text-[#141414]">
      {/* Navigation */}
      <Navbar onOpenJoin={() => handleOpenJoin('Fitness')} />

      <main>
        {/* Editorial Hero Section */}
        <Hero onOpenJoin={() => handleOpenJoin('Fitness')} />

        {/* Horizontal Trust / Social Proof Section */}
        <TrustProof />

        {/* About Section */}
        <About />

        {/* Fitness Experience: 4 Premium Visual Cards */}
        <FitnessExperience onSelectPillar={(pillar) => handleOpenJoin(pillar)} />

        {/* Why GYMIT: 4 Large Editorial Points */}
        <WhyGymit />

        {/* Magazine-Style Image Gallery */}
        <Gallery />

        {/* Reviews & Social Proof */}
        <ReviewsRating />

        {/* Premium Split CTA Section */}
        <PremiumCTA onOpenJoin={() => handleOpenJoin('Fitness')} />

        {/* Location & Map Section */}
        <LocationSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Join Gymit Inquiry Modal */}
      <JoinModal
        isOpen={isJoinModalOpen}
        onClose={handleCloseJoin}
        initialFocus={selectedPillar}
      />

      {/* Floating WhatsApp Action Button */}
      <FloatingWhatsApp />

      {/* Mobile Sticky Quick Contact Bar */}
      <div className="sm:hidden fixed bottom-4 left-4 right-4 z-40 flex items-center shadow-xl border border-[#E8E5DC] bg-[#FAF9F5]/95 backdrop-blur-md p-1.5">
        <a
          href={`tel:${BUSINESS_DATA.phoneClean}`}
          id="mobile-sticky-call-btn"
          className="flex-1 py-3 px-2 flex items-center justify-center space-x-2 text-xs font-semibold tracking-[0.16em] uppercase text-[#141414] bg-white border border-[#E8E5DC] hover:border-[#B8976C]"
        >
          <Phone className="w-3.5 h-3.5 text-[#B8976C]" />
          <span>CALL NOW</span>
        </a>
        <button
          onClick={() => handleOpenJoin('Fitness')}
          id="mobile-sticky-join-btn"
          className="flex-1 py-3 px-2 ml-1.5 flex items-center justify-center text-xs font-semibold tracking-[0.18em] uppercase text-[#FAF9F5] bg-[#141414] hover:bg-[#B8976C] hover:text-[#141414] transition-colors"
        >
          <span>JOIN GYMIT</span>
        </button>
      </div>
    </div>
  );
}
