export interface TrainingPillar {
  id: string;
  title: string;
  description: string;
  image: string;
  aspect: string;
}

export interface WhyPoint {
  number: string;
  title: string;
  detail: string;
  subdetail?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  aspectRatio: 'wide' | 'tall' | 'standard' | 'cinematic';
}

export interface BusinessInfo {
  name: string;
  subName: string;
  category: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  fullAddress: string;
  phone: string;
  phoneClean: string;
  rating: number;
  reviewsCount: number;
  plusCode: string;
  openingInfo: string;
  googleMapsUrl: string;
  googleReviewsUrl: string;
}
